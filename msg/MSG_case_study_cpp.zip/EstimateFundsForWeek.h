#pragma once

class EstimateFundsForWeek
{

public:

  static void compute();		 // computes the estimated funds available for week
  
}; // class EstimateFundsForWeek
