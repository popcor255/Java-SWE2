#pragma once

#include "stdafx.h"
#include "UserInterface.h"
#include "Mortgage.h"

class MortgageReport
{

public:

  static void printReport ();		  // generates the mortgage report
  
}; // class MortgageReport
