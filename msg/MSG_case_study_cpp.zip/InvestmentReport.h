#pragma once

#include "stdafx.h"
#include "UserInterface.h"
#include "Investment.h"

class InvestmentReport
{

public:

  static void printReport ();		  // generates the investment report
  
}; // class InvestmentReport
