#pragma once

#include "stdafx.h"
#include "UserInterface.h"
#include "OperatingExpenses.h"

class EstimatedFundsReport
{

public:

  static void printReport ();		// computes total funds available for purchasing new mortgages in the current week.

}; // class EstimatedFundsReport
